package BigData.Spark;

import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;

public class Test1 {

    public static void main(String[] args) {
    	SparkConf conf = new SparkConf();
        SparkContext sc = new SparkContext(conf);
        
    }

}
