package BigData.Spark

import org.apache.spark.SparkContext

import org.apache.spark.SparkConf

object Test {
  def main(args: Array[String]): Unit = {
    println("Hi")
  }
  
}